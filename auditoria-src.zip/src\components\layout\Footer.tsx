
"use client";

import Image from "next/image";

function GitIcon({ className = "w-4 h-4" }: { className?: string }) {
    return (
        <svg className={className} viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" />
        </svg>
    );
}

function LinkedinIcon({ className = "w-4 h-4" }: { className?: string }) {
    return (
        <svg className={className} viewBox="0 0 24 24" fill="currentColor">
            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
        </svg>
    );
}

export function Footer() {

    const currentYear = 2026;

    return (
        <footer className="fixed bottom-0 inset-x-0 bg-slate-950/90 backdrop-blur-xl border-t border-white/10 py-2 px-6 z-40 pointer-events-auto shadow-2xl">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-mono">

                {/* Lado Esquerdo: Logo igual ao topo */}
                <div className="flex items-center">
                    <a
                        href="#hero"
                        className="flex items-center gap-2 text-sm font-extrabold tracking-wider text-white group"
                    >
                        <div className="w-7 h-7 rounded-lg overflow-hidden flex items-center justify-center group-hover:scale-105 transition-transform bg-slate-900 border border-white/10 shadow-lg">
                            <Image
                                src="/favicon.svg"
                                alt="Logótipo Robson"
                                width={24}
                                height={24}
                                className="w-full h-full object-contain"
                            />
                        </div>
                        <span className="text-gradient-cyan text-xs sm:text-sm">
                            Robson<span className="text-white">.dev</span>
                        </span>
                    </a>
                </div>

                {/* Centro: © Ano oProgramadorAutonomo com link */}
                <div className="text-center">
                    <a
                        href="https://www.linkedin.com/in/robson-soares-b22513170/?isSelfProfile=true"
                        target="_blank"
                        rel="noreferrer"
                        className="text-cyan-400 hover:text-cyan-300 font-semibold text-xs transition-colors"
                    >
                        © {currentYear} oProgramadorAutonomo
                    </a>
                </div>

                {/* Lado Direito: Redes Sociais Coloridas */}
                <div className="flex items-center gap-2.5">
                    <div className="flex items-center gap-1.5">
                        {/* GitHub */}
                        <a
                            href="https://github.com/robsonejsoares"
                            target="_blank"
                            rel="noreferrer"
                            aria-label="GitHub"
                            className="w-6 h-6 rounded-md bg-slate-900/80 border border-white/10 flex items-center justify-center text-slate-100 hover:border-slate-300 hover:bg-slate-800 transition-all group shadow-sm"
                        >
                            <GitIcon className="w-3 h-3 text-slate-100 group-hover:scale-110 transition-transform" />
                        </a>

                        {/* LinkedIn */}
                        <a
                            href="https://www.linkedin.com/in/robson-soares-b22513170/?isSelfProfile=true"
                            target="_blank"
                            rel="noreferrer"
                            aria-label="LinkedIn"
                            className="w-6 h-6 rounded-md bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 hover:bg-blue-500/20 hover:border-blue-400 transition-all group shadow-sm"
                        >
                            <LinkedinIcon className="w-3 h-3 text-blue-400 group-hover:scale-110 transition-transform" />
                        </a>
                    </div>
                </div>

            </div>
        </footer>
    );
}
